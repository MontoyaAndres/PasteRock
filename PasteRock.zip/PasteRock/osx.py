#-*- coding: utf-8 -*-
def osxinfect():
	print "Aún no esta para MAC OSX"
